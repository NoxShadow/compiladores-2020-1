﻿namespace Compiladores20201ProjetoCSharp.Compilador
{
    enum TipoEnum
    {
        Inteiro,
        Real,
        Literal,
        Logico,
        Binario,
        Hexadecimal,
        Erro
    }
}
